import axios from "axios";

export const signup = async ({ name, email, password }) => {
  try {
    const { data } = await axios.post("/api/users/register", { name, email, password });
    return data.data; // { _id, name, email, photo, role }
  } catch (error) {
    const msg = error.response?.data?.message || error.message;
    throw new Error(msg);
  }
};

export const login = async ({ email, password }) => {
  try {
    const { data } = await axios.post("/api/users/login", { email, password });
    return data.data; // { _id, name, email, photo, role }
  } catch (error) {
    const msg = error.response?.data?.message || error.message;
    throw new Error(msg);
  }
};

export const getUserProfile = async ({ token }) => {
  try {
    const { data } = await axios.get("/api/users/profile", {
      withCredentials: true,
      headers: { Authorization: `Bearer ${token}` },
    });
    return data.data;
  } catch (error) {
    const msg = error.response?.data?.message || error.message;
    throw new Error(msg);
  }
};

export const updateProfile = async ({ token, userData }) => {
  try {
    const { data } = await axios.patch("/api/users/updateProfile", userData, {
      withCredentials: true,
      headers: { Authorization: `Bearer ${token}` },
    });
    return data.data;
  } catch (error) {
    const msg = error.response?.data?.message || error.message;
    throw new Error(msg);
  }
};

export const updateProfilePicture = async ({ token, formData }) => {
  try {
    const { data } = await axios.put("/api/users/updateProfilePicture", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${token}`,
      },
    });
    return data.data;
  } catch (error) {
    const msg = error.response?.data?.message || error.message;
    throw new Error(msg);
  }
};

export const getProducts = async ({ page = 1, limit = 20, search = "", category = "" } = {}) => {
  try {
    const params = new URLSearchParams({ page, limit });
    if (search) params.append("search", search);
    if (category) params.append("category", category);
    const { data } = await axios.get(`/api/product?${params}`);
    return data; // { success, data: products[], pagination }
  } catch (error) {
    const msg = error.response?.data?.message || error.message;
    throw new Error(msg);
  }
};

export const getLowStockProducts = async ({ token }) => {
  try {
    const { data } = await axios.get("/api/product/low-stock", {
      withCredentials: true,
      headers: { Authorization: `Bearer ${token}` },
    });
    return data; // { success, data: products[], count }
  } catch (error) {
    const msg = error.response?.data?.message || error.message;
    throw new Error(msg);
  }
};
