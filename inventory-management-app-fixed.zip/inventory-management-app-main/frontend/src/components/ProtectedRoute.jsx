import { useSelector } from "react-redux";
import { Navigate, useLocation } from "react-router-dom";

/**
 * Wraps routes that require authentication.
 * Redirects to /login with the original destination saved.
 */
const ProtectedRoute = ({ children, adminOnly = false }) => {
  const userInfo = useSelector((state) => state.user.userInfo);
  const location = useLocation();

  if (!userInfo) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (adminOnly && userInfo.role !== "admin") {
    return <Navigate to="/" replace />;
  }

  return children;
};

export default ProtectedRoute;
