import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

const Navbar = ({
  onSidebarToggle,
  onDarkModeToggle,
  isSearchFormVisible,
  onSearchToggle,
}) => {
  const userState = useSelector((state) => state.user);
  const navigate = useNavigate();
  const user = userState.userInfo;

  return (
    <nav>
      <i className="bx bx-menu" onClick={onSidebarToggle}></i>
      <form
        className={isSearchFormVisible ? "show" : ""}
        onSubmit={(e) => e.preventDefault()}
      >
        <div className="form-input">
          <input type="search" placeholder="Search products…" />
          <button className="search-btn" type="button" onClick={onSearchToggle}>
            <i className="bx bx-search"></i>
          </button>
        </div>
      </form>
      <input
        type="checkbox"
        id="theme-toggle"
        hidden
        onChange={onDarkModeToggle}
      />
      <label htmlFor="theme-toggle" className="theme-toggle"></label>

      <Link to="/profile" className="profile" title={user?.name || "Profile"}>
        <img
          src={user?.photo || `https://robohash.org/${user?._id || "user"}.png`}
          alt={user?.name || "Profile"}
          onError={(e) => {
            e.target.src = `https://robohash.org/${user?._id || "user"}.png`;
          }}
        />
      </Link>
    </nav>
  );
};

export default Navbar;
