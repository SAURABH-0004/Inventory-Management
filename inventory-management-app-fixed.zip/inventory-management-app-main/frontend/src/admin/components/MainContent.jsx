import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useSelector } from "react-redux";
import axios from "axios";
import Customers from "./Customers";

const MainContent = ({ isDarkMode }) => {
  const userState = useSelector((state) => state.user);
  const token = userState.userInfo ? userState.userInfo._id : "";

  // Fetch real product stats
  const { data: productsData, isLoading: productsLoading } = useQuery({
    queryKey: ["products-stats"],
    queryFn: () =>
      axios.get("/api/product?limit=1000").then((r) => r.data),
    refetchInterval: 30000,
  });

  // Fetch low stock products
  const { data: lowStockData } = useQuery({
    queryKey: ["low-stock"],
    queryFn: () =>
      axios
        .get("/api/product/low-stock", { withCredentials: true })
        .then((r) => r.data),
    refetchInterval: 60000,
  });

  const products = productsData?.data || [];
  const totalProducts = productsData?.pagination?.total || 0;
  const lowStockCount = lowStockData?.count || 0;
  const totalValue = products.reduce((sum, p) => sum + (p.price || 0) * (p.quantity || 0), 0);
  const categories = [...new Set(products.map((p) => p.category))].length;

  const Stat = ({ icon, value, label, colorClass, loading }) => (
    <li>
      <i className={`bx ${icon}`} style={{ background: undefined }}></i>
      <span className="info">
        <h3>{loading ? "..." : value}</h3>
        <p>{label}</p>
      </span>
    </li>
  );

  return (
    <main>
      <div className="header">
        <div className="left">
          <h1>Dashboard</h1>
          <ul className="breadcrumb">
            <li><a href="/analytics">Analytics</a></li>
            <li><a href="/shop" className="active">Shop</a></li>
          </ul>
        </div>
        <button
          className="report"
          onClick={() => {
            const rows = [
              ["Product", "Category", "Price", "Quantity", "Value"],
              ...products.map((p) => [p.product, p.category, p.price, p.quantity, p.price * p.quantity]),
            ];
            const csv = rows.map((r) => r.join(",")).join("\n");
            const blob = new Blob([csv], { type: "text/csv" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = "inventory-report.csv";
            a.click();
            URL.revokeObjectURL(url);
          }}
        >
          <i className="bx bx-cloud-download"></i>
          <span>Download CSV</span>
        </button>
      </div>

      {/* Low stock alert */}
      {lowStockCount > 0 && (
        <div
          style={{
            background: "var(--light-danger)",
            color: "var(--danger)",
            borderRadius: 12,
            padding: "12px 20px",
            marginTop: 20,
            display: "flex",
            alignItems: "center",
            gap: 10,
            fontWeight: 600,
          }}
        >
          <i className="bx bx-error-circle" style={{ fontSize: 20 }}></i>
          ⚠️ {lowStockCount} product{lowStockCount > 1 ? "s are" : " is"} running low on stock.
        </div>
      )}

      <ul className="insights">
        <li>
          <i className="bx bx-package" style={{ background: "var(--light-primary)", color: "var(--primary)" }}></i>
          <span className="info">
            <h3>{productsLoading ? "..." : totalProducts}</h3>
            <p>Total Products</p>
          </span>
        </li>
        <li>
          <i className="bx bx-category" style={{ background: "var(--light-warning)", color: "var(--warning)" }}></i>
          <span className="info">
            <h3>{productsLoading ? "..." : categories}</h3>
            <p>Categories</p>
          </span>
        </li>
        <li>
          <i className="bx bx-error" style={{ background: "var(--light-danger)", color: "var(--danger)" }}></i>
          <span className="info">
            <h3>{productsLoading ? "..." : lowStockCount}</h3>
            <p>Low Stock</p>
          </span>
        </li>
        <li>
          <i className="bx bx-dollar-circle" style={{ background: "var(--light-success)", color: "var(--success)" }}></i>
          <span className="info">
            <h3>{productsLoading ? "..." : `$${totalValue.toLocaleString()}`}</h3>
            <p>Inventory Value</p>
          </span>
        </li>
      </ul>

      <div className="bottom-data">
        <div className="orders" style={{ flex: 2 }}>
          <div className="header">
            <i className="bx bx-receipt"></i>
            <h3>Products Inventory</h3>
          </div>
          {productsLoading ? (
            <p style={{ color: "var(--dark-grey)", padding: "20px 0" }}>Loading products...</p>
          ) : products.length === 0 ? (
            <p style={{ color: "var(--dark-grey)", padding: "20px 0" }}>No products yet. Add your first product.</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th>Qty</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {products.slice(0, 10).map((p) => (
                  <tr key={p._id}>
                    <td>{p.product}</td>
                    <td>{p.category}</td>
                    <td>${Number(p.price).toFixed(2)}</td>
                    <td>{p.quantity}</td>
                    <td>
                      <span
                        className={`status ${
                          p.quantity === 0
                            ? "pending"
                            : p.isLowStock
                            ? "process"
                            : "completed"
                        }`}
                      >
                        {p.quantity === 0 ? "Out of Stock" : p.isLowStock ? "Low Stock" : "In Stock"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="reminders">
          <div className="header">
            <i className="bx bx-note"></i>
            <h3>Low Stock Alerts</h3>
          </div>
          <ul className="task-list">
            {lowStockData?.data?.length > 0 ? (
              lowStockData.data.slice(0, 5).map((p) => (
                <li key={p._id} className={p.quantity === 0 ? "not-completed" : "completed"}>
                  <div className="task-title">
                    <i className={`bx ${p.quantity === 0 ? "bx-x-circle" : "bx-error"}`}></i>
                    <p>
                      {p.product} ({p.quantity} left)
                    </p>
                  </div>
                  <i className="bx bx-dots-vertical-rounded"></i>
                </li>
              ))
            ) : (
              <li className="completed" style={{ justifyContent: "center" }}>
                <div className="task-title">
                  <i className="bx bx-check-circle"></i>
                  <p>All stock levels OK</p>
                </div>
              </li>
            )}
          </ul>
        </div>

        <div className="customers">
          <Customers />
        </div>
      </div>
    </main>
  );
};

export default MainContent;
