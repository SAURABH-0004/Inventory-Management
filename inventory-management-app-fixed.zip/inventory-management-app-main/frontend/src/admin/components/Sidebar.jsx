import React from "react";
import { Link, useLocation } from "react-router-dom";
import { useDispatch } from "react-redux";
import { logout } from "../../store/actions/user";

const Sidebar = ({ isClosed }) => {
  const location = useLocation();
  const dispatch = useDispatch();

  const isActive = (path) => location.pathname === path;

  const NavItem = ({ to, icon, label }) => (
    <li className={isActive(to) ? "active" : ""}>
      <Link to={to}>
        <i className={`bx ${icon}`}></i>
        {label}
      </Link>
    </li>
  );

  return (
    <div className={`sidebar ${isClosed ? "close" : ""}`}>
      <Link to="/" className="logo">
        <i className="bx bx-cube-alt"></i>
        <div className="logo-name">
          <span>Inven</span>tory
        </div>
      </Link>
      <ul className="side-menu">
        <NavItem to="/dashboard" icon="bxs-dashboard" label="Dashboard" />
        <NavItem to="/dashboard/products" icon="bx-package" label="Products" />
        <NavItem to="/dashboard/categories" icon="bx-category" label="Categories" />
        <NavItem to="/dashboard/low-stock" icon="bx-error-alt" label="Low Stock" />
        <NavItem to="/profile" icon="bx-user" label="Profile" />
      </ul>
      <ul className="side-menu">
        <li>
          <button
            onClick={() => dispatch(logout())}
            className="logout"
            style={{
              width: "100%",
              height: "100%",
              borderRadius: 48,
              fontSize: 16,
              color: "var(--danger)",
              whiteSpace: "nowrap",
              overflow: "hidden",
              background: "transparent",
              border: "none",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              padding: "0 4px",
            }}
          >
            <i className="bx bx-log-out-circle"></i>
            Logout
          </button>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
