import React, { useState } from "react";
import { Routes, Route, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { useEffect } from "react";

import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
import MainContent from "../components/MainContent";
import ProductsPage from "../../pages/products/ProductsPage";
import CategoriesPage from "../../pages/categories/CategoriesPage";
import LowStockPage from "../../pages/lowstock/LowStockPage";

const Home = () => {
  const userState = useSelector((state) => state.user);
  const storedDarkMode = localStorage.getItem("darkMode") === "true";

  const [isSidebarClosed, setIsSidebarClosed] = useState(false);
  const [isSearchFormVisible, setIsSearchFormVisible] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(storedDarkMode);
  const navigate = useNavigate();

  const handleDarkModeToggle = () => {
    const next = !isDarkMode;
    setIsDarkMode(next);
    localStorage.setItem("darkMode", next);
  };

  useEffect(() => {
    if (!userState.userInfo) {
      navigate("/login");
    }
  }, [navigate, userState.userInfo]);

  return (
    <div className={`app ${isDarkMode ? "dark" : ""} admin-home-container`}>
      <Sidebar isClosed={isSidebarClosed} />
      <div className="content">
        <Navbar
          onSidebarToggle={() => setIsSidebarClosed((s) => !s)}
          onSearchToggle={() => setIsSearchFormVisible((s) => !s)}
          isSearchFormVisible={isSearchFormVisible}
          onDarkModeToggle={handleDarkModeToggle}
        />
        <Routes>
          <Route index element={<MainContent isDarkMode={isDarkMode} />} />
          <Route path="products" element={<ProductsPage />} />
          <Route path="categories" element={<CategoriesPage />} />
          <Route path="low-stock" element={<LowStockPage />} />
        </Routes>
      </div>
    </div>
  );
};

export default Home;
