import React from "react";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";

const LowStockPage = () => {
  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ["low-stock"],
    queryFn: () =>
      axios.get("/api/product/low-stock", { withCredentials: true }).then((r) => r.data),
    refetchInterval: 60000,
  });

  const products = data?.data || [];

  return (
    <div style={{ padding: 24 }}>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 style={{ fontSize: 28, fontWeight: 700, color: "var(--dark)", marginBottom: 4 }}>
            Low Stock Alerts
          </h1>
          <p style={{ color: "var(--dark-grey)", fontSize: 13 }}>
            Products at or below their minimum stock threshold
          </p>
        </div>
        <button
          onClick={() => refetch()}
          style={{
            background: "var(--light-primary)",
            color: "var(--primary)",
            border: "none",
            borderRadius: 36,
            padding: "10px 22px",
            fontWeight: 600,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          <i className="bx bx-refresh" style={{ fontSize: 18 }} />
          Refresh
        </button>
      </div>

      {isLoading ? (
        <div style={{ textAlign: "center", padding: 80, color: "var(--dark-grey)" }}>
          <i className="bx bx-loader-alt bx-spin" style={{ fontSize: 48 }} />
          <p style={{ marginTop: 12 }}>Checking stock levels…</p>
        </div>
      ) : isError ? (
        <div style={{ textAlign: "center", padding: 80, color: "var(--danger)" }}>
          <i className="bx bx-error-circle" style={{ fontSize: 48 }} />
          <p style={{ marginTop: 12 }}>Failed to load stock data.</p>
        </div>
      ) : products.length === 0 ? (
        <div style={{ textAlign: "center", padding: 80, color: "var(--dark-grey)" }}>
          <span style={{ fontSize: 64 }}>✅</span>
          <p style={{ marginTop: 16, fontSize: 20, fontWeight: 700, color: "var(--success)" }}>
            All stock levels are healthy!
          </p>
          <p style={{ fontSize: 13, marginTop: 4 }}>
            No products are currently below their minimum threshold.
          </p>
        </div>
      ) : (
        <>
          <div
            style={{
              background: "var(--light-danger)",
              color: "var(--danger)",
              borderRadius: 12,
              padding: "14px 20px",
              marginBottom: 24,
              display: "flex",
              alignItems: "center",
              gap: 10,
              fontWeight: 600,
            }}
          >
            <i className="bx bx-error" style={{ fontSize: 20 }} />
            {products.length} product{products.length > 1 ? "s need" : " needs"} restocking
          </div>

          <div style={{ background: "var(--light)", borderRadius: 20, padding: 24 }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  {["Product", "Category", "Price", "In Stock", "Min Stock", "Shortfall", "Status"].map((h) => (
                    <th
                      key={h}
                      style={{
                        padding: "12px 16px",
                        textAlign: "left",
                        fontSize: 12,
                        fontWeight: 700,
                        color: "var(--dark-grey)",
                        borderBottom: "2px solid var(--grey)",
                        textTransform: "uppercase",
                        letterSpacing: "0.05em",
                      }}
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {products.map((p) => {
                  const isOut = p.quantity === 0;
                  const shortfall = Math.max(0, (p.minStock || 5) - p.quantity);
                  return (
                    <tr
                      key={p._id}
                      style={{ borderBottom: "1px solid var(--grey)", cursor: "pointer" }}
                      onMouseEnter={(e) => (e.currentTarget.style.background = "var(--grey)")}
                      onMouseLeave={(e) => (e.currentTarget.style.background = "")}
                    >
                      <td style={{ padding: "14px 16px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                          {p.image ? (
                            <img
                              src={p.image}
                              alt={p.product}
                              style={{ width: 36, height: 36, borderRadius: 8, objectFit: "cover" }}
                              onError={(e) => (e.target.style.display = "none")}
                            />
                          ) : (
                            <div
                              style={{
                                width: 36,
                                height: 36,
                                borderRadius: 8,
                                background: "var(--grey)",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                fontSize: 18,
                              }}
                            >
                              📦
                            </div>
                          )}
                          <span style={{ fontWeight: 600, color: "var(--dark)" }}>
                            {p.product}
                          </span>
                        </div>
                      </td>
                      <td style={{ padding: "14px 16px", color: "var(--dark-grey)", fontSize: 13 }}>
                        {p.category}
                      </td>
                      <td style={{ padding: "14px 16px", fontWeight: 600, color: "var(--dark)" }}>
                        ${Number(p.price).toFixed(2)}
                      </td>
                      <td style={{ padding: "14px 16px" }}>
                        <span
                          style={{
                            fontWeight: 700,
                            fontSize: 16,
                            color: isOut ? "var(--danger)" : "var(--warning)",
                          }}
                        >
                          {p.quantity}
                        </span>
                      </td>
                      <td style={{ padding: "14px 16px", color: "var(--dark-grey)" }}>
                        {p.minStock || 5}
                      </td>
                      <td style={{ padding: "14px 16px" }}>
                        <span
                          style={{
                            background: "var(--light-danger)",
                            color: "var(--danger)",
                            fontWeight: 700,
                            padding: "3px 10px",
                            borderRadius: 20,
                            fontSize: 12,
                          }}
                        >
                          -{shortfall}
                        </span>
                      </td>
                      <td style={{ padding: "14px 16px" }}>
                        <span
                          style={{
                            background: isOut ? "var(--danger)" : "var(--warning)",
                            color: "#fff",
                            fontWeight: 700,
                            padding: "4px 12px",
                            borderRadius: 20,
                            fontSize: 11,
                            textTransform: "uppercase",
                            letterSpacing: "0.05em",
                          }}
                        >
                          {isOut ? "Out of Stock" : "Low Stock"}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
};

export default LowStockPage;
