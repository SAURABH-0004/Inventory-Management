import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import toast from "react-hot-toast";

import MainLayout from "../../components/MainLayout";
import { getUserProfile, updateProfile } from "../../services/index/users";
import ProfilePicture from "../../components/ProfilePicture";
import { userActions } from "../../store/reducers/userReducers";

const ProfilePage = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const queryClient = useQueryClient();
  const userState = useSelector((state) => state.user);

  // userInfo is now a user object { _id, name, email, photo, role }
  // The token for Bearer auth is stored in the httpOnly cookie on the server side.
  // For client-side profile fetch we pass the _id so the server can look it up.
  const userInfo = userState.userInfo;

  const {
    data: profileData,
    isLoading: profileIsLoading,
  } = useQuery({
    queryFn: () => getUserProfile({ token: userInfo?._id }),
    queryKey: ["profile"],
    enabled: !!userInfo,
  });

  const { mutate, isLoading: updateIsLoading } = useMutation({
    mutationFn: ({ name, email, password, phone, bio }) =>
      updateProfile({
        token: userInfo?._id,
        userData: { name, email, password, phone, bio },
      }),
    onSuccess: (data) => {
      dispatch(userActions.setUserInfo({ ...userInfo, ...data }));
      localStorage.setItem("account", JSON.stringify({ ...userInfo, ...data }));
      queryClient.invalidateQueries(["profile"]);
      toast.success("Profile updated!");
    },
    onError: (error) => toast.error(error.message),
  });

  useEffect(() => {
    if (!userInfo) navigate("/login");
  }, [navigate, userInfo]);

  const {
    register,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm({
    defaultValues: { name: "", email: "", password: "", phone: "", bio: "" },
    values: {
      name: profileIsLoading ? "" : (profileData?.name || userInfo?.name || ""),
      email: profileIsLoading ? "" : (profileData?.email || userInfo?.email || ""),
      phone: profileIsLoading ? "" : (profileData?.phone || ""),
      bio: profileIsLoading ? "" : (profileData?.bio || ""),
    },
    mode: "onChange",
  });

  return (
    <MainLayout>
      <section className="container mx-auto px-5 py-10">
        <div className="w-full max-w-sm mx-auto">
          <h1 className="text-3xl font-bold text-gray-800 text-center mb-6">
            My Profile
          </h1>

          {/* Avatar */}
          <div className="flex justify-center mb-6">
            <img
              src={profileData?.photo || userInfo?.photo || `https://robohash.org/${userInfo?._id}.png`}
              alt="Profile"
              className="w-24 h-24 rounded-full object-cover border-4 border-blue-100"
              onError={(e) => {
                e.target.src = `https://robohash.org/${userInfo?._id}.png`;
              }}
            />
          </div>

          <form onSubmit={handleSubmit((d) => mutate(d))}>
            {[
              { id: "name", label: "Name", type: "text", rules: { required: "Name is required", minLength: { value: 2, message: "Min 2 characters" } } },
              { id: "email", label: "Email", type: "email", rules: { required: "Email is required" } },
              { id: "phone", label: "Phone", type: "text", rules: {} },
            ].map(({ id, label, type, rules }) => (
              <div key={id} className="flex flex-col mb-5 w-full">
                <label htmlFor={id} className="text-[#5a7184] font-semibold block">
                  {label}
                </label>
                <input
                  type={type}
                  id={id}
                  {...register(id, rules)}
                  className={`placeholder:text-[#959ead] text-dark-hard mt-3 rounded-lg px-5 py-4 block outline-none border ${
                    errors[id] ? "border-red-500" : "border-[#c3cad9]"
                  }`}
                />
                {errors[id] && (
                  <p className="text-red-500 text-xs mt-1">{errors[id].message}</p>
                )}
              </div>
            ))}

            <div className="flex flex-col mb-5 w-full">
              <label htmlFor="bio" className="text-[#5a7184] font-semibold block">
                Bio
              </label>
              <textarea
                id="bio"
                {...register("bio", { maxLength: { value: 250, message: "Max 250 characters" } })}
                rows={3}
                className="placeholder:text-[#959ead] text-dark-hard mt-3 rounded-lg px-5 py-4 block outline-none border border-[#c3cad9] resize-none"
                placeholder="Tell us about yourself"
              />
            </div>

            <div className="flex flex-col mb-6 w-full">
              <label htmlFor="password" className="text-[#5a7184] font-semibold block">
                New Password <span className="font-normal text-xs">(leave blank to keep current)</span>
              </label>
              <input
                type="password"
                id="password"
                {...register("password", {
                  minLength: { value: 6, message: "Minimum 6 characters" },
                })}
                placeholder="New password (optional)"
                className={`placeholder:text-[#959ead] text-dark-hard mt-3 rounded-lg px-5 py-4 font-semibold block outline-none border ${
                  errors.password ? "border-red-500" : "border-[#c3cad9]"
                }`}
              />
              {errors.password && (
                <p className="text-red-500 text-xs mt-1">{errors.password.message}</p>
              )}
            </div>

            <button
              type="submit"
              disabled={!isValid || profileIsLoading || updateIsLoading}
              className="bg-primary text-white font-bold text-lg py-4 px-8 w-full rounded-lg mb-6 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {updateIsLoading ? "Updating…" : "Update Profile"}
            </button>
          </form>
        </div>
      </section>
    </MainLayout>
  );
};

export default ProfilePage;
