import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useSelector } from "react-redux";
import axios from "axios";
import toast from "react-hot-toast";
import { useForm } from "react-hook-form";

const fetchCategories = () =>
  axios.get("/api/category").then((r) => r.data?.data || r.data || []);

const CategoryForm = ({ initial, onSubmit, isLoading, onCancel }) => {
  const {
    register,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm({
    defaultValues: initial || { title: "", description: "" },
    mode: "onChange",
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3">
      <div>
        <label className="block text-sm font-semibold text-gray-600 mb-1">
          Category Name
        </label>
        <input
          {...register("title", {
            required: "Name is required",
            minLength: { value: 2, message: "Min 2 characters" },
          })}
          placeholder="e.g. Electronics"
          className={`w-full border rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-blue-300 text-gray-800 ${
            errors.title ? "border-red-400" : "border-gray-200"
          }`}
        />
        {errors.title && (
          <p className="text-red-500 text-xs mt-1">{errors.title.message}</p>
        )}
      </div>
      <div>
        <label className="block text-sm font-semibold text-gray-600 mb-1">
          Description (optional)
        </label>
        <input
          {...register("description")}
          placeholder="Short description"
          className="w-full border border-gray-200 rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-blue-300 text-gray-800"
        />
      </div>
      <div className="flex gap-3 mt-2">
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 border border-gray-200 text-gray-600 py-2 rounded-lg hover:bg-gray-50 transition"
          >
            Cancel
          </button>
        )}
        <button
          type="submit"
          disabled={!isValid || isLoading}
          className="flex-1 bg-blue-600 text-white font-bold py-2 rounded-lg hover:bg-blue-700 transition disabled:opacity-60"
        >
          {isLoading ? "Saving…" : initial ? "Update" : "Add Category"}
        </button>
      </div>
    </form>
  );
};

const CategoriesPage = () => {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(null);
  const [showAdd, setShowAdd] = useState(false);

  const { data: categories = [], isLoading } = useQuery({
    queryKey: ["categories"],
    queryFn: fetchCategories,
  });

  const addMutation = useMutation({
    mutationFn: (body) =>
      axios.post("/api/category", body, { withCredentials: true }),
    onSuccess: () => {
      toast.success("Category added!");
      queryClient.invalidateQueries(["categories"]);
      setShowAdd(false);
    },
    onError: (e) =>
      toast.error(e.response?.data?.message || "Failed to add category"),
  });

  const editMutation = useMutation({
    mutationFn: (body) =>
      axios.put(`/api/category/${editing._id}`, body, {
        withCredentials: true,
      }),
    onSuccess: () => {
      toast.success("Category updated!");
      queryClient.invalidateQueries(["categories"]);
      setEditing(null);
    },
    onError: (e) =>
      toast.error(e.response?.data?.message || "Failed to update"),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) =>
      axios.delete(`/api/category/${id}`, { withCredentials: true }),
    onSuccess: () => {
      toast.success("Category deleted.");
      queryClient.invalidateQueries(["categories"]);
    },
    onError: (e) =>
      toast.error(e.response?.data?.message || "Failed to delete"),
  });

  const COLORS = [
    "bg-blue-50 text-blue-600",
    "bg-purple-50 text-purple-600",
    "bg-green-50 text-green-600",
    "bg-yellow-50 text-yellow-600",
    "bg-pink-50 text-pink-600",
    "bg-orange-50 text-orange-600",
  ];

  return (
    <div style={{ padding: 24 }}>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1
            style={{
              fontSize: 28,
              fontWeight: 700,
              color: "var(--dark)",
              marginBottom: 4,
            }}
          >
            Categories
          </h1>
          <p style={{ color: "var(--dark-grey)", fontSize: 13 }}>
            {categories.length} categories
          </p>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          style={{
            background: "var(--primary)",
            color: "#fff",
            border: "none",
            borderRadius: 36,
            padding: "10px 22px",
            fontWeight: 600,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          <i className="bx bx-plus" style={{ fontSize: 20 }} />
          Add Category
        </button>
      </div>

      {/* Add form inline */}
      {showAdd && (
        <div
          style={{
            background: "var(--light)",
            borderRadius: 16,
            padding: 20,
            marginBottom: 20,
            border: "2px dashed var(--primary)",
          }}
        >
          <h3
            style={{
              fontWeight: 700,
              marginBottom: 16,
              color: "var(--dark)",
            }}
          >
            New Category
          </h3>
          <CategoryForm
            onSubmit={(d) => addMutation.mutate(d)}
            isLoading={addMutation.isLoading}
            onCancel={() => setShowAdd(false)}
          />
        </div>
      )}

      {isLoading ? (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(260px,1fr))",
            gap: 16,
          }}
        >
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              style={{
                height: 100,
                borderRadius: 16,
                background: "#f3f4f6",
                animation: "pulse 1.5s infinite",
              }}
            />
          ))}
        </div>
      ) : categories.length === 0 ? (
        <div style={{ textAlign: "center", padding: 80, color: "var(--dark-grey)" }}>
          <span style={{ fontSize: 64 }}>🗂️</span>
          <p style={{ marginTop: 16, fontSize: 18, fontWeight: 600 }}>
            No categories yet
          </p>
          <p style={{ fontSize: 13, marginTop: 4 }}>
            Add your first category to organise products.
          </p>
        </div>
      ) : (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(280px,1fr))",
            gap: 16,
          }}
        >
          {categories.map((cat, i) =>
            editing?._id === cat._id ? (
              <div
                key={cat._id}
                style={{
                  background: "var(--light)",
                  borderRadius: 16,
                  padding: 20,
                  border: "2px solid var(--primary)",
                }}
              >
                <CategoryForm
                  initial={cat}
                  onSubmit={(d) => editMutation.mutate(d)}
                  isLoading={editMutation.isLoading}
                  onCancel={() => setEditing(null)}
                />
              </div>
            ) : (
              <div
                key={cat._id}
                style={{
                  background: "var(--light)",
                  borderRadius: 16,
                  padding: 20,
                  border: "1px solid var(--grey)",
                  display: "flex",
                  alignItems: "center",
                  gap: 16,
                }}
              >
                <div
                  style={{
                    width: 52,
                    height: 52,
                    borderRadius: 12,
                    background:
                      i % 2 === 0
                        ? "var(--light-primary)"
                        : i % 3 === 0
                        ? "var(--light-success)"
                        : "var(--light-warning)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 22,
                    flexShrink: 0,
                  }}
                >
                  🗂️
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p
                    style={{
                      fontWeight: 700,
                      color: "var(--dark)",
                      marginBottom: 2,
                    }}
                  >
                    {cat.title || cat.name}
                  </p>
                  {cat.description && (
                    <p
                      style={{
                        fontSize: 12,
                        color: "var(--dark-grey)",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                      }}
                    >
                      {cat.description}
                    </p>
                  )}
                </div>
                <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                  <button
                    onClick={() => setEditing(cat)}
                    style={{
                      background: "var(--light-primary)",
                      color: "var(--primary)",
                      border: "none",
                      borderRadius: 8,
                      padding: "6px 12px",
                      cursor: "pointer",
                      fontSize: 12,
                      fontWeight: 600,
                    }}
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => {
                      if (window.confirm(`Delete "${cat.title || cat.name}"?`))
                        deleteMutation.mutate(cat._id);
                    }}
                    style={{
                      background: "var(--light-danger)",
                      color: "var(--danger)",
                      border: "none",
                      borderRadius: 8,
                      padding: "6px 12px",
                      cursor: "pointer",
                      fontSize: 12,
                      fontWeight: 600,
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            )
          )}
        </div>
      )}
    </div>
  );
};

export default CategoriesPage;
