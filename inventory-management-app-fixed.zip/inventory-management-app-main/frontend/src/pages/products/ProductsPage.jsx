import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useSelector } from "react-redux";
import axios from "axios";
import toast from "react-hot-toast";
import { useForm } from "react-hook-form";

// ── API helpers ──────────────────────────────────────────────────
const fetchProducts = ({ page, search, category }) =>
  axios
    .get(`/api/product?page=${page}&limit=12${search ? `&search=${search}` : ""}${category ? `&category=${category}` : ""}`)
    .then((r) => r.data);

const fetchCategories = () =>
  axios.get("/api/category").then((r) => r.data?.data || r.data || []);

// ── Modal ────────────────────────────────────────────────────────
const Modal = ({ title, onClose, children }) => (
  <div
    className="fixed inset-0 z-50 flex items-center justify-center"
    style={{ background: "rgba(0,0,0,0.5)" }}
    onClick={(e) => e.target === e.currentTarget && onClose()}
  >
    <div
      className="bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 overflow-hidden"
      style={{ maxHeight: "90vh", overflowY: "auto" }}
    >
      <div className="flex items-center justify-between px-6 py-4 border-b">
        <h2 className="text-xl font-bold text-gray-800">{title}</h2>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-600 text-2xl leading-none"
        >
          ×
        </button>
      </div>
      <div className="p-6">{children}</div>
    </div>
  </div>
);

// ── Product Form ─────────────────────────────────────────────────
const ProductForm = ({ initial, categories, onSubmit, isLoading }) => {
  const {
    register,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm({
    defaultValues: initial || {
      product: "",
      category: "",
      price: "",
      quantity: "",
      minStock: 5,
      description: "",
      image: "",
    },
    mode: "onChange",
  });

  const field = (label, name, opts = {}) => (
    <div className="mb-4">
      <label className="block text-sm font-semibold text-gray-600 mb-1">
        {label}
      </label>
      <input
        {...register(name, opts)}
        className={`w-full border rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-blue-300 text-gray-800 ${
          errors[name] ? "border-red-400" : "border-gray-200"
        }`}
      />
      {errors[name] && (
        <p className="text-red-500 text-xs mt-1">{errors[name].message}</p>
      )}
    </div>
  );

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      {field("Product Name", "product", {
        required: "Name is required",
        minLength: { value: 2, message: "Min 2 characters" },
        maxLength: { value: 30, message: "Max 30 characters" },
      })}

      <div className="mb-4">
        <label className="block text-sm font-semibold text-gray-600 mb-1">
          Category
        </label>
        <select
          {...register("category", { required: "Category is required" })}
          className="w-full border border-gray-200 rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-blue-300 text-gray-800"
        >
          <option value="">— Select category —</option>
          {categories.map((c) => (
            <option key={c._id || c} value={c.title || c.name || c}>
              {c.title || c.name || c}
            </option>
          ))}
        </select>
        {errors.category && (
          <p className="text-red-500 text-xs mt-1">{errors.category.message}</p>
        )}
      </div>

      <div className="grid grid-cols-3 gap-3">
        {field("Price ($)", "price", {
          required: "Price is required",
          min: { value: 0, message: "Must be ≥ 0" },
          valueAsNumber: true,
        })}
        {field("Quantity", "quantity", {
          required: "Quantity is required",
          min: { value: 0, message: "Must be ≥ 0" },
          valueAsNumber: true,
        })}
        {field("Min Stock", "minStock", {
          min: { value: 0, message: "Must be ≥ 0" },
          valueAsNumber: true,
        })}
      </div>

      <div className="mb-4">
        <label className="block text-sm font-semibold text-gray-600 mb-1">
          Description
        </label>
        <textarea
          {...register("description", {
            required: "Description is required",
            minLength: { value: 15, message: "Min 15 characters" },
            maxLength: { value: 500, message: "Max 500 characters" },
          })}
          rows={3}
          className={`w-full border rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-blue-300 text-gray-800 resize-none ${
            errors.description ? "border-red-400" : "border-gray-200"
          }`}
        />
        {errors.description && (
          <p className="text-red-500 text-xs mt-1">
            {errors.description.message}
          </p>
        )}
      </div>

      {field("Image URL or Base64", "image", {
        required: "Image is required",
      })}

      <button
        type="submit"
        disabled={!isValid || isLoading}
        className="w-full bg-blue-600 text-white font-bold py-3 rounded-lg mt-2 hover:bg-blue-700 transition disabled:opacity-60 disabled:cursor-not-allowed"
      >
        {isLoading ? "Saving…" : initial ? "Update Product" : "Add Product"}
      </button>
    </form>
  );
};

// ── Delete confirm ───────────────────────────────────────────────
const DeleteConfirm = ({ product, onConfirm, onCancel, isLoading }) => (
  <div className="text-center">
    <div className="text-5xl mb-4">🗑️</div>
    <p className="text-gray-700 mb-2">
      Are you sure you want to delete{" "}
      <strong className="text-gray-900">{product.product}</strong>?
    </p>
    <p className="text-sm text-gray-400 mb-6">This action cannot be undone.</p>
    <div className="flex gap-3">
      <button
        onClick={onCancel}
        className="flex-1 border border-gray-200 text-gray-600 py-2 rounded-lg hover:bg-gray-50 transition"
      >
        Cancel
      </button>
      <button
        onClick={onConfirm}
        disabled={isLoading}
        className="flex-1 bg-red-500 text-white py-2 rounded-lg hover:bg-red-600 transition disabled:opacity-60"
      >
        {isLoading ? "Deleting…" : "Delete"}
      </button>
    </div>
  </div>
);

// ── Product Card ─────────────────────────────────────────────────
const ProductCard = ({ product, onEdit, onDelete }) => {
  const isOut = product.quantity === 0;
  const isLow = !isOut && product.quantity <= (product.minStock ?? 5);

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow">
      <div className="relative h-40 bg-gray-50 flex items-center justify-center overflow-hidden">
        {product.image ? (
          <img
            src={product.image}
            alt={product.product}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.target.style.display = "none";
            }}
          />
        ) : (
          <span className="text-5xl">📦</span>
        )}
        {(isOut || isLow) && (
          <span
            className={`absolute top-2 right-2 text-xs font-bold px-2 py-1 rounded-full ${
              isOut
                ? "bg-red-500 text-white"
                : "bg-yellow-400 text-yellow-900"
            }`}
          >
            {isOut ? "Out of Stock" : "Low Stock"}
          </span>
        )}
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-1">
          <h3 className="font-bold text-gray-800 text-sm leading-tight line-clamp-1">
            {product.product}
          </h3>
          <span className="text-blue-600 font-bold text-sm whitespace-nowrap">
            ${Number(product.price).toFixed(2)}
          </span>
        </div>
        <span className="inline-block bg-blue-50 text-blue-600 text-xs font-semibold px-2 py-0.5 rounded mb-2">
          {product.category}
        </span>
        <p className="text-gray-400 text-xs line-clamp-2 mb-3">
          {product.description}
        </p>
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-500">
            Qty:{" "}
            <span
              className={`font-bold ${
                isOut
                  ? "text-red-500"
                  : isLow
                  ? "text-yellow-500"
                  : "text-green-600"
              }`}
            >
              {product.quantity}
            </span>
          </span>
          <div className="flex gap-2">
            <button
              onClick={() => onEdit(product)}
              className="text-xs bg-gray-100 hover:bg-blue-100 text-gray-600 hover:text-blue-600 px-3 py-1 rounded-lg transition"
            >
              Edit
            </button>
            <button
              onClick={() => onDelete(product)}
              className="text-xs bg-gray-100 hover:bg-red-100 text-gray-600 hover:text-red-600 px-3 py-1 rounded-lg transition"
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// ── Skeleton loader ──────────────────────────────────────────────
const SkeletonCard = () => (
  <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden animate-pulse">
    <div className="h-40 bg-gray-100" />
    <div className="p-4 space-y-2">
      <div className="h-4 bg-gray-100 rounded w-3/4" />
      <div className="h-3 bg-gray-100 rounded w-1/2" />
      <div className="h-3 bg-gray-100 rounded w-full" />
      <div className="h-3 bg-gray-100 rounded w-5/6" />
    </div>
  </div>
);

// ── Main Page ────────────────────────────────────────────────────
const ProductsPage = () => {
  const userState = useSelector((state) => state.user);
  const queryClient = useQueryClient();

  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [filterCategory, setFilterCategory] = useState("");
  const [modal, setModal] = useState(null); // null | 'add' | 'edit' | 'delete'
  const [selected, setSelected] = useState(null);

  const token = userState.userInfo?._id || "";

  const { data, isLoading, isError } = useQuery({
    queryKey: ["products", page, search, filterCategory],
    queryFn: () => fetchProducts({ page, search, category: filterCategory }),
    keepPreviousData: true,
  });

  const { data: categoriesData } = useQuery({
    queryKey: ["categories"],
    queryFn: fetchCategories,
  });

  const categories = Array.isArray(categoriesData) ? categoriesData : [];
  const products = data?.data || [];
  const pagination = data?.pagination || {};

  const closeModal = () => {
    setModal(null);
    setSelected(null);
  };

  const addMutation = useMutation({
    mutationFn: (body) =>
      axios.post("/api/product/create", body, { withCredentials: true }),
    onSuccess: () => {
      toast.success("Product added!");
      queryClient.invalidateQueries(["products"]);
      closeModal();
    },
    onError: (e) =>
      toast.error(e.response?.data?.message || "Failed to add product"),
  });

  const editMutation = useMutation({
    mutationFn: (body) =>
      axios.put(`/api/product/${selected._id}`, body, {
        withCredentials: true,
      }),
    onSuccess: () => {
      toast.success("Product updated!");
      queryClient.invalidateQueries(["products"]);
      closeModal();
    },
    onError: (e) =>
      toast.error(e.response?.data?.message || "Failed to update product"),
  });

  const deleteMutation = useMutation({
    mutationFn: () =>
      axios.delete(`/api/product/${selected._id}`, { withCredentials: true }),
    onSuccess: () => {
      toast.success("Product deleted.");
      queryClient.invalidateQueries(["products"]);
      closeModal();
    },
    onError: (e) =>
      toast.error(e.response?.data?.message || "Failed to delete product"),
  });

  const handleSearch = (e) => {
    e.preventDefault();
    setSearch(searchInput);
    setPage(1);
  };

  return (
    <div style={{ padding: "24px" }}>
      {/* Header */}
      <div
        className="flex flex-wrap items-center justify-between gap-4 mb-6"
      >
        <div>
          <h1
            style={{
              fontSize: 28,
              fontWeight: 700,
              color: "var(--dark)",
              marginBottom: 4,
            }}
          >
            Products
          </h1>
          <p style={{ color: "var(--dark-grey)", fontSize: 13 }}>
            {pagination.total ?? 0} products total
          </p>
        </div>
        <button
          onClick={() => setModal("add")}
          style={{
            background: "var(--primary)",
            color: "#fff",
            border: "none",
            borderRadius: 36,
            padding: "10px 22px",
            fontWeight: 600,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          <i className="bx bx-plus" style={{ fontSize: 20 }} />
          Add Product
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-6">
        <form onSubmit={handleSearch} className="flex gap-2">
          <input
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search products…"
            style={{
              border: "1px solid #eee",
              borderRadius: 36,
              padding: "8px 18px",
              outline: "none",
              fontSize: 13,
              color: "var(--dark)",
              background: "var(--light)",
              minWidth: 200,
            }}
          />
          <button
            type="submit"
            style={{
              background: "var(--primary)",
              color: "#fff",
              border: "none",
              borderRadius: 36,
              padding: "8px 18px",
              cursor: "pointer",
              fontSize: 13,
            }}
          >
            Search
          </button>
          {search && (
            <button
              type="button"
              onClick={() => {
                setSearch("");
                setSearchInput("");
                setPage(1);
              }}
              style={{
                background: "var(--light-danger)",
                color: "var(--danger)",
                border: "none",
                borderRadius: 36,
                padding: "8px 14px",
                cursor: "pointer",
                fontSize: 13,
              }}
            >
              Clear
            </button>
          )}
        </form>

        <select
          value={filterCategory}
          onChange={(e) => {
            setFilterCategory(e.target.value);
            setPage(1);
          }}
          style={{
            border: "1px solid #eee",
            borderRadius: 36,
            padding: "8px 18px",
            outline: "none",
            fontSize: 13,
            color: "var(--dark)",
            background: "var(--light)",
            cursor: "pointer",
          }}
        >
          <option value="">All Categories</option>
          {categories.map((c) => (
            <option key={c._id || c} value={c.title || c.name || c}>
              {c.title || c.name || c}
            </option>
          ))}
        </select>
      </div>

      {/* Grid */}
      {isError ? (
        <div
          style={{
            textAlign: "center",
            padding: 60,
            color: "var(--danger)",
          }}
        >
          <i className="bx bx-error-circle" style={{ fontSize: 48 }} />
          <p style={{ marginTop: 12 }}>Failed to load products.</p>
        </div>
      ) : isLoading ? (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
            gap: 16,
          }}
        >
          {Array.from({ length: 8 }).map((_, i) => (
            <SkeletonCard key={i} />
          ))}
        </div>
      ) : products.length === 0 ? (
        <div style={{ textAlign: "center", padding: 80, color: "var(--dark-grey)" }}>
          <span style={{ fontSize: 64 }}>📦</span>
          <p style={{ marginTop: 16, fontSize: 18, fontWeight: 600 }}>
            No products found
          </p>
          <p style={{ fontSize: 13, marginTop: 4 }}>
            {search
              ? "Try a different search term."
              : "Add your first product to get started."}
          </p>
        </div>
      ) : (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
            gap: 16,
          }}
        >
          {products.map((p) => (
            <ProductCard
              key={p._id}
              product={p}
              onEdit={(p) => {
                setSelected(p);
                setModal("edit");
              }}
              onDelete={(p) => {
                setSelected(p);
                setModal("delete");
              }}
            />
          ))}
        </div>
      )}

      {/* Pagination */}
      {pagination.pages > 1 && (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            gap: 8,
            marginTop: 32,
          }}
        >
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            style={{
              padding: "8px 16px",
              borderRadius: 8,
              border: "1px solid #eee",
              cursor: page === 1 ? "not-allowed" : "pointer",
              background: "var(--light)",
              color: "var(--dark)",
              opacity: page === 1 ? 0.4 : 1,
            }}
          >
            ← Prev
          </button>
          {Array.from({ length: pagination.pages }, (_, i) => i + 1).map(
            (p) => (
              <button
                key={p}
                onClick={() => setPage(p)}
                style={{
                  padding: "8px 14px",
                  borderRadius: 8,
                  border: "none",
                  cursor: "pointer",
                  background: p === page ? "var(--primary)" : "var(--grey)",
                  color: p === page ? "#fff" : "var(--dark)",
                  fontWeight: p === page ? 700 : 400,
                }}
              >
                {p}
              </button>
            )
          )}
          <button
            onClick={() => setPage((p) => Math.min(pagination.pages, p + 1))}
            disabled={page === pagination.pages}
            style={{
              padding: "8px 16px",
              borderRadius: 8,
              border: "1px solid #eee",
              cursor:
                page === pagination.pages ? "not-allowed" : "pointer",
              background: "var(--light)",
              color: "var(--dark)",
              opacity: page === pagination.pages ? 0.4 : 1,
            }}
          >
            Next →
          </button>
        </div>
      )}

      {/* Modals */}
      {modal === "add" && (
        <Modal title="Add New Product" onClose={closeModal}>
          <ProductForm
            categories={categories}
            onSubmit={(data) => addMutation.mutate(data)}
            isLoading={addMutation.isLoading}
          />
        </Modal>
      )}

      {modal === "edit" && selected && (
        <Modal title="Edit Product" onClose={closeModal}>
          <ProductForm
            initial={selected}
            categories={categories}
            onSubmit={(data) => editMutation.mutate(data)}
            isLoading={editMutation.isLoading}
          />
        </Modal>
      )}

      {modal === "delete" && selected && (
        <Modal title="Delete Product" onClose={closeModal}>
          <DeleteConfirm
            product={selected}
            onConfirm={() => deleteMutation.mutate()}
            onCancel={closeModal}
            isLoading={deleteMutation.isLoading}
          />
        </Modal>
      )}
    </div>
  );
};

export default ProductsPage;
