import { createSlice } from "@reduxjs/toolkit";

const storedUser = (() => {
  try {
    const stored = localStorage.getItem("account");
    return stored ? JSON.parse(stored) : null;
  } catch {
    return null;
  }
})();

const userSlice = createSlice({
  name: "user",
  initialState: { userInfo: storedUser },
  reducers: {
    setUserInfo(state, action) {
      state.userInfo = action.payload;
    },
    resetUserInfo(state) {
      state.userInfo = null;
    },
  },
});

export const userActions = userSlice.actions;
export const userReducer = userSlice.reducer;
export default userSlice.reducer;
