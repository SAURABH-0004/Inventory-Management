import { configureStore } from "@reduxjs/toolkit";
import { userReducer } from "./reducers/userReducers";

// userReducer already initialises from localStorage internally
const store = configureStore({
  reducer: {
    user: userReducer,
  },
});

export default store;
