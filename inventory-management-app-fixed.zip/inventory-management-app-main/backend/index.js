const express = require("express");
const dotenv = require("dotenv");
const morgan = require("morgan");
const cors = require("cors");
const helmet = require("helmet");
const mongoSanitize = require("express-mongo-sanitize");
const connectDB = require("./database/connect");
const errorHandler = require("./middleware/errorsMiddleware");
const cookieParser = require("cookie-parser");

dotenv.config({ path: ".env" });

const app = express();

// Security headers
app.use(helmet());

// CORS - fixed: whitelist only, with credentials
const allowedOrigins = [
  process.env.CLIENT_URL || "http://localhost:3000",
];
app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin || allowedOrigins.includes(origin)) {
        return callback(null, true);
      }
      callback(new Error("Not allowed by CORS"));
    },
    credentials: true,
  })
);

app.use(morgan("tiny"));
app.use(cookieParser());
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// Prevent MongoDB injection attacks
app.use(mongoSanitize());

app.use("/api/users", require("./routes/userRoutes"));
app.use("/api/category", require("./routes/categoryRoutes"));
app.use("/api/product", require("./routes/productRoutes"));

const PORT = process.env.PORT || 9000;

app.use(errorHandler);
connectDB();

app.listen(PORT, () => {
  console.log(`server started on http://localhost:${PORT}`);
});
