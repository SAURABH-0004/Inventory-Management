const User = require("../models/User");
const jwt = require("jsonwebtoken");

// Cookie-based protection (for browser clients)
const protect = async (req, res, next) => {
  try {
    const token = req.cookies.token;
    if (!token) {
      return res.status(401).json({ success: false, message: "Not authorized, no token" });
    }
    const verified = jwt.verify(token, process.env.SECRET_KEY);
    const user = await User.findById(verified._id).select("-password");
    if (!user) {
      return res.status(401).json({ success: false, message: "Not authorized, user not found" });
    }
    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({ success: false, message: "Not authorized, token failed" });
  }
};

// Bearer token protection (for API clients)
const authGuard = async (req, res, next) => {
  if (req.headers.authorization?.startsWith("Bearer")) {
    const token = req.headers.authorization.split(" ")[1];
    try {
      const decoded = jwt.verify(token, process.env.SECRET_KEY);
      const user = await User.findById(decoded._id).select("-password");
      if (!user) {
        return res.status(401).json({ success: false, message: "User not found" });
      }
      req.user = user;
      next();
    } catch (error) {
      return res.status(401).json({ success: false, message: "Token invalid" });
    }
  } else {
    return res.status(401).json({ success: false, message: "No token provided" });
  }
};

// FIXED: now checks req.user.role === "admin" (User schema has role field now)
const adminGuard = (req, res, next) => {
  if (req.user && req.user.role === "admin") {
    next();
  } else {
    return res.status(403).json({ success: false, message: "Access denied: admin only" });
  }
};

module.exports = { protect, authGuard, adminGuard };
