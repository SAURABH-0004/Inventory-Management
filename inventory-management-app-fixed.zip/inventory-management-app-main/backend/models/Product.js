const mongoose = require("mongoose");
const createSlug = require("../utils/createSlug");

const productSchema = new mongoose.Schema(
  {
    product: {
      type: String,
      required: [true, "Product name is required"],
    },
    category: {
      type: String,
      required: [true, "Category is required"],
    },
    // FIXED: price must be Number for sorting, filtering, and calculations
    price: {
      type: Number,
      required: [true, "Price is required"],
      min: [0, "Price cannot be negative"],
    },
    quantity: {
      type: Number,
      required: [true, "Quantity is required"],
      min: [0, "Quantity cannot be negative"],
    },
    // NEW: low stock threshold
    minStock: {
      type: Number,
      default: 5,
    },
    description: {
      type: String,
      required: [true, "Product description is required"],
    },
    image: {
      type: String,
      required: [true, "Image is required"],
    },
    slug: {
      type: String,
    },
    // FIXED: was cloudinary_id: result.public_url (typo) - now stores public_id for deletion
    cloudinary_id: {
      type: String,
    },
  },
  { timestamps: true }
);

// Virtual: computed low stock flag
productSchema.virtual("isLowStock").get(function () {
  return this.quantity <= this.minStock;
});

productSchema.set("toJSON", { virtuals: true });
productSchema.set("toObject", { virtuals: true });

productSchema.pre("save", async function (next) {
  if (!this.isModified("product")) return next();
  this.slug = createSlug(this.product);
  next();
});

const Product = mongoose.model("Product", productSchema);
module.exports = Product;
