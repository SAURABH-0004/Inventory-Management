const express = require("express");
const router = express.Router();
const upload = require("../utils/imageUpload");
const { protect, adminGuard } = require("../middleware/authMiddleware");
const {
  addProduct,
  getProducts,
  getProduct,
  getLowStockProducts,
  updateProduct,
  deleteProduct,
} = require("../controllers/productController");

// Public
router.get("/", getProducts);
router.get("/low-stock", protect, getLowStockProducts);
router.get("/:id", getProduct);

// Protected
router.post("/create", protect, upload.single("image"), addProduct);
router.put("/:id", protect, updateProduct);
router.delete("/:id", protect, deleteProduct);

module.exports = router;
