const express = require("express");
const router = express.Router();
const rateLimit = require("express-rate-limit");
const {
  register,
  login,
  logout,
  user,
  loggedIn,
  updateProfile,
  changePassword,
  forgotPassword,
  resetPassword,
} = require("../controllers/userController");
const { protect, authGuard } = require("../middleware/authMiddleware");

// Rate limiter for auth endpoints - prevents brute force
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10,
  message: { success: false, message: "Too many attempts from this IP, please try again after 15 minutes." },
  standardHeaders: true,
  legacyHeaders: false,
});

router.post("/register", authLimiter, register);
router.post("/login", authLimiter, login);
router.get("/logout", logout);
router.get("/profile", authGuard, user);
router.get("/loggedIn", loggedIn);
router.patch("/updateProfile", protect, updateProfile);
router.patch("/changePassword", protect, changePassword);
router.post("/forgotPassword", authLimiter, forgotPassword);
router.put("/resetPassword/:resetToken", resetPassword);

module.exports = router;
