const Product = require("../models/Product");
const joi = require("joi");
const cloudinary = require("../config/cloudinary.config");

const productSchema = joi.object({
  product: joi.string().required().max(30).min(2),
  category: joi.string().required(),
  // FIXED: price is now Number in schema
  price: joi.number().required().min(0),
  quantity: joi.number().required().min(0),
  minStock: joi.number().min(0).default(5),
  description: joi.string().required().max(500).min(15),
  image: joi.string().required(),
});

const addProduct = async (req, res) => {
  try {
    const { error } = productSchema.validate(req.body);
    if (error) return res.status(400).json({ success: false, message: error.details[0].message });

    const { product, category, price, quantity, minStock, description, image } = req.body;

    const existing = await Product.findOne({ product });
    if (existing) return res.status(400).json({ success: false, message: `Product "${product}" already exists` });

    const result = await cloudinary.uploader.upload(image, { folder: "inventory" });

    const newProduct = new Product({
      product, category, price, quantity,
      minStock: minStock || 5,
      description, slug: product,
      image: result.secure_url,
      // FIXED: was result.public_url (typo) - must be public_id for deletion
      cloudinary_id: result.public_id,
    });

    await newProduct.save();
    return res.status(201).json({ success: true, message: "Product saved.", data: newProduct });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// FIXED: added pagination - Product.find() without limit will crash at scale
const getProducts = async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, parseInt(req.query.limit) || 20);
    const skip = (page - 1) * limit;

    const search = req.query.search;
    const category = req.query.category;

    const filter = {};
    if (search) filter.product = { $regex: search, $options: "i" };
    if (category) filter.category = category;

    const [products, total] = await Promise.all([
      Product.find(filter).skip(skip).limit(limit).sort({ createdAt: -1 }),
      Product.countDocuments(filter),
    ]);

    return res.status(200).json({
      success: true,
      data: products,
      pagination: { total, page, limit, pages: Math.ceil(total / limit) },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

const getProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ success: false, message: "Product not found." });
    return res.status(200).json({ success: true, data: product });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// NEW: Low stock endpoint
const getLowStockProducts = async (req, res) => {
  try {
    const products = await Product.find({
      $expr: { $lte: ["$quantity", "$minStock"] },
    });
    return res.status(200).json({ success: true, data: products, count: products.length });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

const updateProduct = async (req, res) => {
  try {
    const updateSchema = joi.object({
      product: joi.string().max(30).min(2),
      category: joi.string(),
      price: joi.number().min(0),
      quantity: joi.number().min(0),
      minStock: joi.number().min(0),
      description: joi.string().max(500).min(15),
      image: joi.string(),
    });

    const { error } = updateSchema.validate(req.body);
    if (error) return res.status(400).json({ success: false, message: error.details[0].message });

    const existing = await Product.findById(req.params.id);
    if (!existing) return res.status(404).json({ success: false, message: "Product not found." });

    let imageUpdate = {};
    if (req.body.image && req.body.image !== existing.image) {
      // FIXED: delete old Cloudinary image before uploading new one
      if (existing.cloudinary_id) {
        await cloudinary.uploader.destroy(existing.cloudinary_id);
      }
      const result = await cloudinary.uploader.upload(req.body.image, { folder: "inventory" });
      imageUpdate = { image: result.secure_url, cloudinary_id: result.public_id };
    }

    const updated = await Product.findByIdAndUpdate(
      req.params.id,
      { ...req.body, ...imageUpdate },
      { new: true, runValidators: true }
    );

    return res.status(200).json({ success: true, message: "Product updated.", data: updated });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

const deleteProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ success: false, message: "Product not found." });

    // FIXED: clean up Cloudinary asset on delete
    if (product.cloudinary_id) {
      await cloudinary.uploader.destroy(product.cloudinary_id);
    }

    await Product.findByIdAndDelete(req.params.id);
    return res.status(200).json({ success: true, message: "Product deleted." });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { addProduct, getProducts, getProduct, getLowStockProducts, updateProduct, deleteProduct };
