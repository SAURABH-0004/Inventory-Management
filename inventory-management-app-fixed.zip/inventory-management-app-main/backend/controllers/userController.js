const joi = require("joi");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const User = require("../models/User");
const Token = require("../models/Token");
const sendEmail = require("../utils/sendEmail");

const setCookieToken = (res, token) => {
  res.cookie("token", token, {
    path: "/",
    httpOnly: true,
    // FIXED: typo was "scure" - cookie was NOT actually secure before
    secure: process.env.NODE_ENV === "production",
    sameSite: process.env.NODE_ENV === "production" ? "strict" : "lax",
    maxAge: 24 * 60 * 60 * 1000, // 1 day
  });
};

const register = async (req, res) => {
  try {
    const schema = joi.object({
      name: joi.string().min(2).max(25).required(),
      email: joi.string().required().email(),
      password: joi.string().min(6).required(),
    });

    const { error } = schema.validate(req.body);
    if (error) return res.status(400).json({ success: false, message: error.details[0].message });

    const { email, name, password } = req.body;
    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ success: false, message: "User with this email already exists." });

    const user = await new User({ name, email, password }).save();

    const token = jwt.sign({ _id: user._id }, process.env.SECRET_KEY, { expiresIn: "1d" });
    setCookieToken(res, token);

    // FIXED: never return the JWT in the response body - return user data only
    return res.status(201).json({
      success: true,
      message: "Registration successful",
      data: { _id: user._id, name: user.name, email: user.email, photo: user.photo, role: user.role },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

const login = async (req, res) => {
  try {
    const schema = joi.object({
      email: joi.string().email().required(),
      password: joi.string().required(),
    });

    const { error } = schema.validate(req.body);
    if (error) return res.status(400).json({ success: false, message: error.details[0].message });

    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ success: false, message: "Invalid email or password" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ success: false, message: "Invalid email or password" });

    const token = jwt.sign({ _id: user._id }, process.env.SECRET_KEY, { expiresIn: "1d" });
    setCookieToken(res, token);

    // FIXED: return user info, not the JWT
    return res.status(200).json({
      success: true,
      message: "Login successful",
      data: { _id: user._id, name: user.name, email: user.email, photo: user.photo, role: user.role },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

const logout = async (req, res) => {
  res.cookie("token", "", {
    path: "/",
    httpOnly: true,
    // FIXED: typo was "scure"
    secure: process.env.NODE_ENV === "production",
    sameSite: process.env.NODE_ENV === "production" ? "strict" : "lax",
    expires: new Date(0),
  });
  return res.status(200).json({ success: true, message: "Logged out successfully." });
};

const getUser = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select("-password");
    if (!user) return res.status(404).json({ success: false, message: "User not found" });
    return res.status(200).json({ success: true, data: user });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

const loggedIn = async (req, res) => {
  try {
    const token = req.cookies.token;
    if (!token) return res.json(false);
    const verified = jwt.verify(token, process.env.SECRET_KEY);
    return res.json(!!verified);
  } catch (error) {
    return res.json(false);
  }
};

const updateProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) return res.status(404).json({ success: false, message: "User not found." });

    user.name = req.body.name || user.name;
    user.photo = req.body.photo || user.photo;
    user.phone = req.body.phone || user.phone;
    user.bio = req.body.bio || user.bio;

    const updated = await user.save();

    return res.status(200).json({
      success: true,
      message: "Profile updated",
      data: { _id: updated._id, name: updated.name, email: updated.email, photo: updated.photo, role: updated.role },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

const changePassword = async (req, res) => {
  try {
    const schema = joi.object({
      password: joi.string().min(6).required(),
      oldPassword: joi.string().required(),
    });

    const { error } = schema.validate(req.body);
    if (error) return res.status(400).json({ success: false, message: error.details[0].message });

    const user = await User.findById(req.user._id);
    if (!user) return res.status(404).json({ success: false, message: "User not found" });

    const isMatch = await bcrypt.compare(req.body.oldPassword, user.password);
    if (!isMatch) return res.status(400).json({ success: false, message: "Current password is incorrect." });

    user.password = req.body.password;
    await user.save();

    return res.status(200).json({ success: true, message: "Password changed successfully." });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

const forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ success: false, message: "User not found." });

    // FIXED: was user.user_id (wrong) - should be user._id
    const existing = await Token.findOne({ userId: user._id });
    if (existing) await existing.deleteOne();

    const resetToken = crypto.randomBytes(32).toString("hex") + user._id;
    const hashedToken = crypto.createHash("sha256").update(resetToken).digest("hex");

    await new Token({
      userId: user._id,
      token: hashedToken,
      createdAt: Date.now(),
      expiresAt: Date.now() + 30 * 60 * 1000,
    }).save();

    const reset_url = `${process.env.CLIENT_URL}/reset-password/${resetToken}`;
    const message = `<h2>Hello ${user.name}</h2><p>Click to reset your password (valid 30 mins):</p><a href="${reset_url}">${reset_url}</a>`;

    try {
      await sendEmail("Password Reset", message, user.email, process.env.EMAIL_USER);
      return res.status(200).json({ success: true, message: "Reset email sent." });
    } catch (err) {
      await Token.findOneAndDelete({ userId: user._id });
      return res.status(500).json({ success: false, message: "Email could not be sent." });
    }
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

const resetPassword = async (req, res) => {
  try {
    const { password } = req.body;
    const { resetToken } = req.params;
    const hashedToken = crypto.createHash("sha256").update(resetToken).digest("hex");

    const userToken = await Token.findOne({ token: hashedToken, expiresAt: { $gt: Date.now() } });
    if (!userToken) return res.status(404).json({ success: false, message: "Token is invalid or expired." });

    const user = await User.findById(userToken.userId);
    user.password = password;
    await user.save();
    await userToken.deleteOne();

    return res.status(200).json({ success: true, message: "Password reset successfully. You can now log in." });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { register, login, logout, user: getUser, loggedIn, updateProfile, changePassword, forgotPassword, resetPassword };
